<?php
/*
# ------------------------------------------------------------------------
# JA Extenstion Manager Component j16
# ------------------------------------------------------------------------
# Copyright (C) 2004-2009 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
# @license - Copyrighted Commercial Software
# Author: J.O.O.M Solutions Co., Ltd
# Websites:  http://www.joomlart.com -  http://www.joomlancers.com
# This file may not be redistributed in whole or significant part.
# ------------------------------------------------------------------------
*/

//no direct access
defined( '_JEXEC' ) or die( 'Retricted Access' );
?>
<div align="diff-source">
<div id="diff-view-mode" style="display:none;">
<pre><code></code></pre>
</div>
<div id="diff-edit-mode" style="display:none; text-align:center;">
<form name="frmSource" id="frmSource" action="" enctype="multipart/form-data">
<textarea name="txtSource" id="txtSource" class="ja-editor-code" onscroll="scrollEditor(this);" wrap="off"></textarea>
</form>
<br />
</div>
</div>
